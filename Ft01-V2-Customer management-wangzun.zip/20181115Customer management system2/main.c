#include <stdio.h>
#include <stdlib.h>
struct Customer
{
    int  Customer_id;
    char first_name[25];
    char last_name[25];
};

// Function of input the data of the management.
 void Input_data( struct Customer cus_arr[] , int max){

   printf("\n This is for input the data of the management: \n");

    for(int i=1;i<=max;i++){
       printf("\n 1.Customer id (1--%d) : ",max);
       scanf( "%d" , &cus_arr[i-1].Customer_id);
       fflush(stdin);

       printf("\n Customer's first name : ");
       fgets(cus_arr[i-1].first_name,25,stdin);

       printf("\n Customer's last name : ");
       fgets(cus_arr[i-1].last_name,25,stdin); }
 }

 void Output_data( struct Customer cus_arr[] , int max){

   printf("\n This is for display the data of the management: \n");

     for(int i=1;i<=max;i++){

       printf("\n Customer id: %d \n",cus_arr[i-1].Customer_id );
       printf(" Customer first name: %s ",cus_arr[i-1].first_name );
       printf("Customer last name: %s ",cus_arr[i-1].last_name ); }
 }

 void Search_data( struct Customer cus_arr[] , int max){

     printf("\n This is for searching the data of the management:\n");

     int answer;
     int position = -1;

     printf("\n Enter the customer id for searching(1--%d): ",max);
     scanf("%d",&answer);

     for(int i=1;i<=max;i++){

       if(cus_arr[i-1].Customer_id == answer){
          position = i-1;
          break;
        }
       }

       if (position == -1){
         printf("\n Customer id %d is not found..", answer);
         }
       else{
         printf("\n Customer id: %d \n",cus_arr[answer-1].Customer_id );
         printf(" Customer first name: %s ",cus_arr[answer-1].first_name );
         printf("Customer last name: %s \n",cus_arr[answer-1].last_name );
         }
 }


int main()
{
     const int max = 3;
     struct Customer cus_arr[max];

     Input_data( cus_arr , max);
     Output_data( cus_arr , max);

     Search_data( cus_arr , max);


      printf("\n End of Customers Management Application,Bye-bye! \n");

      return 0;
}
